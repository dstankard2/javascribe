/*
 * Created on Mar 5, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.sf.jsom.java5;

import java.util.List;

import net.sf.jsom.CodeGenerationException;
import net.sf.jsom.VariableTypeResolver;

/**
 * @author User
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Java5DeclaredMethod extends Java5MethodSignature {
	
	private boolean isStatic = false;
	
	private Java5CompatibleCodeSnippet methodBody = null;
	
	public Java5DeclaredMethod(VariableTypeResolver acc) { 
		super(acc); 
		methodBody = new Java5CodeSnippet();
	}
	
	public Java5CompatibleCodeSnippet getMethodBody() {
		return methodBody;
	}
	public void setMethodBody(Java5CompatibleCodeSnippet methodBody) {
		this.methodBody = methodBody;
	}

	public List<String> getImports() throws CodeGenerationException {
		List<String> ret = null;
		
		ret = super.getImports();
		if (methodBody!=null) {
			Java5Util.appendImports(ret, methodBody.getRequiredImports());
		}
		
		return ret;
	}
	
	public StringBuffer getSource() throws CodeGenerationException {
		StringBuffer buf = new StringBuffer();
		
		buf.append(this.getMethodDeclarationText());
		buf.append(" {\n");
		if (getMethodBody()!=null)
			buf.append(getMethodBody().getSource());
		buf.append("\n  }\n");

		return buf;
	}

	public Java5MethodSignature createDuplicateMethodSignature() throws CodeGenerationException {
		Java5MethodSignature ret = null;
		String name = null;
		List<String> argNames = null;
		Java5MethodParameter param = null;
		
		ret = new Java5MethodSignature(types);
		
		argNames = this.getArgNames();
		
		for(int i=0;i<argNames.size();i++) {
			name = argNames.get(i);
			param = args.get(name);
			ret.addArg(param);
		}
		ret.setMethodName(getMethodName());
		ret.setReturnType(getReturnType());
		ret.setThrownExceptions(getThrownExceptions());
		
		return ret;
	}

	public boolean isStatic() {
		return isStatic;
	}

	public void setStatic(boolean isStatic) {
		this.isStatic = isStatic;
	}
}


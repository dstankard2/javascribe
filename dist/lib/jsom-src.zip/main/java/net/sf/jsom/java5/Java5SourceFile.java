/*
 * Created on Mar 5, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.sf.jsom.java5;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import net.sf.jsom.CodeGenerationException;
import net.sf.jsom.VariableTypeResolver;
import net.sf.jsom.SourceFile;

/**
 * @author User
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Java5SourceFile extends SourceFile {
	protected Java5ClassDefinition publicClass = null;
	protected String packageName = null;
	protected VariableTypeResolver types = null;
	protected String sourceRoot = null;
	protected List<String> localImports = new ArrayList<String>();
	
	public VariableTypeResolver getVariableTypeResolver() {
		return types;
	}

	public void addImport(String s) {
		if (!localImports.contains(s))
			localImports.add(s);
	}
	
	public Java5SourceFile(VariableTypeResolver r) { 
		if (r==null) {
			throw new IllegalArgumentException("JSOM internal error: Tried to create Java file without variable type resolver.");
		}
		types = r;
		publicClass = new Java5ClassDefinition(this);
	}

	public Java5ClassDefinition getPublicClass() {
		return publicClass;
	}
	
	public StringBuilder getSource() throws CodeGenerationException {
		StringBuilder ret = new StringBuilder();
		String value = null;
		List<String> imports = null;
		
		ret.append('\n');
		ret.append("package "+getPackageName()+";\n\n");

		imports = publicClass.getImports();
		for(int i=0;i<imports.size();i++) {
			value = imports.get(i);
			ret.append("import "+value+";\n");
		}
		for(int i=0;i<localImports.size();i++) {
			value = localImports.get(i);
			ret.append("import "+value+";\n");
		}
		ret.append(publicClass.getSource());

		return ret;
	}

	public String getPackageName() {
		return packageName;
	}
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public void setSourceRootPath(String s) {
		sourceRoot = s;
	}
	
	public String getPath() {
		return sourceRoot+File.separatorChar+getRelativePath();
	}
	
	public String getRelativePath() {
	    String ret = null;
	    
	    if (packageName==null) packageName = "";
	    ret = packageName+'.'+publicClass.getClassName();
	    
	    ret = ret.replace('.',File.separatorChar)+".java";
	    
	    return ret;
	}
}


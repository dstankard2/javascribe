package net.sf.jsom.java5;

import net.sf.jsom.VariableType;

public interface Java5CompatibleType extends VariableType {

	public String getImport();
	public String getClassName();
	
}


/*
 * Created on Aug 12, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.sf.jsom;

/**
 * @author User
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface CodeSnippet {

	/**
	 * Returns a string representing the code in this snippet.
	 * @return String of code.
	 */
	public String getSource() throws CodeGenerationException;

	/**
	 * Appends the code snippet "other" to the end of this code snippet.
	 * @param other Code snippet to append.
	 */
	public void merge(CodeSnippet other) throws CodeGenerationException;
	
	/**
	 * Appends the specified string of code to the end of this code snippet.
	 * @param s String of code to append.
	 */
	public CodeSnippet append(String s);
	
}

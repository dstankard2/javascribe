package net.sf.jsom.java5;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author Dave
 *
 */
public class Java5Code implements Java5CodePart {
	StringBuffer value = null;
	List<String> imports = new ArrayList<String>();
	
	public List<String> getImports() {
		return imports;
	}

	public void addImport(String className) {
		if (!imports.contains(className)) {
			imports.add(className);
		}
	}
	
	public Java5Code(String s) {
		value = new StringBuffer(s);
	}
	
	public void append(String s) {
		value.append(s);
	}
	
	public void append(char c) {
		value.append(c);
	}
	
	public String getCode() { return value.toString(); }

}


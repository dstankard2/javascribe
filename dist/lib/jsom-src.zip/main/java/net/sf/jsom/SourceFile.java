/*
 * Created on Feb 26, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.sf.jsom;

/**
 * @author Dave
 *
 * Represents a basic source code file.  A source file consists of a path and content.
 */
public class SourceFile {
	private String path = null;
	private StringBuilder source = null;

	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public StringBuilder getSource() throws CodeGenerationException {
		return source;
	}
	public void setSource(StringBuilder source) {
		this.source = source;
	}

}

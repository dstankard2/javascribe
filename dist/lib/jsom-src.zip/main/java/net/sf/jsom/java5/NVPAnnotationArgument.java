package net.sf.jsom.java5;

import java.util.ArrayList;
import java.util.List;


/**
 * This class represents an annotation argument that consists of an argument name 
 * and a value.  The value has a type, and the generated Java 5 code reflects that 
 * type.
 * @author Dave
 *
 */
public class NVPAnnotationArgument implements AnnotationArgument {
	private String name = null;
	private StringBuffer valueBuffer = null;
	List<Object> valueList = null;
	
	// For use when the value for this argument is an array
	public NVPAnnotationArgument(String name,List<Object> valueList) {
		if (name==null)
			throw new IllegalArgumentException("Cannot specify a null name in NVPAnnotationArgument");
		if (valueList==null)
			throw new IllegalArgumentException("Cannot specify a null value in NVPAnnotationArgument");

		this.name = name;
		this.valueList = valueList;
	}
	
	public NVPAnnotationArgument(String name,String value) {
		if (name==null)
			throw new IllegalArgumentException("Cannot specify a null name in NVPAnnotationArgument");
		if (value==null)
			throw new IllegalArgumentException("Cannot specify a null value in NVPAnnotationArgument");

		this.name = name;
		this.valueBuffer = new StringBuffer(value);
	}

	public List<String> getImports() {
		List<String> ret = new ArrayList<String>();
		Object ob = null;
		Java5Annotation ann = null;
		
		if (valueList!=null) {
			for(int i=0;i<valueList.size();i++) {
				ob = valueList.get(i);
				if (ob instanceof Java5Annotation) {
					ann = (Java5Annotation)ob;
					Java5Util.appendImports(ret, ann.getImports());
				}
			}
		}
		
		return ret;
	}
	
	public NVPAnnotationArgument(String name,StringBuffer valueBuffer) {
		if (name==null)
			throw new IllegalArgumentException("Cannot specify a null name in NVPAnnotationArgument");
		if (valueBuffer==null)
			throw new IllegalArgumentException("Cannot specify a null value in NVPAnnotationArgument");

		this.name = name;
		this.valueBuffer = valueBuffer;
	}

	public String getCode() {
		StringBuffer buf = new StringBuffer();
		
		buf.append(name).append('=');
		if (valueList!=null) {
			Object val = null;
			buf.append('{');
			
			for(int i=0;i<valueList.size();i++) {
				if (i>0) buf.append(',');
				val = valueList.get(i);
				if (val instanceof Java5Annotation) {
					buf.append(((Java5Annotation)val).getCode());
				} else {
					buf.append(valueList.get(i));
				}
			}
			buf.append('}');
		} else if (valueBuffer!=null) {
			buf.append(valueBuffer);
		}
		return buf.toString();
	}
}

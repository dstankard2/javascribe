package net.sf.jsom.java5;

import java.util.List;

import net.sf.jsom.CodeGenerationException;
import net.sf.jsom.VariableTypeResolver;

public class Java5Util {

	public static void appendImports(List<String> base,List<String> append) {
		for(int i=0;i<append.size();i++) {
			if (!base.contains(append.get(i))) {
				base.add(append.get(i));
			}
		}
	}
	
	public static void addImport(String className,List<String> imports) {
		if (!imports.contains(className)) {
			imports.add(className);
		}
	}
	
	public static void addImport(String typeName,List<String> ims,VariableTypeResolver types) throws CodeGenerationException {
		Java5Type type = null;
		if (typeName.indexOf("list/")==0) {
			type = (Java5Type)types.getVariableType("list");
			if (type.getImport()!=null) {
				addImport(type.getImport(),ims);
			}
			type = (Java5Type)types.getVariableType(typeName.substring(5));
			if (type==null) {
				throw new CodeGenerationException("Couldn't find element type for list of type '"+typeName+"'");
			}
			if (type.getImport()!=null) {
				addImport(type.getImport(),ims);
			}
		} else if (typeName.indexOf("map-")==0) {
			type = (Java5Type)types.getVariableType("map");
			if (type.getImport()!=null) {
				addImport(type.getImport(),ims);
			}
			type = (Java5Type)types.getVariableType(typeName.substring(4));
			if (type==null) {
				throw new CodeGenerationException("Couldn't find element type for map of type '"+typeName+"'");
			}
			if (type.getImport()!=null) {
				addImport(type.getImport(),ims);
			}
		} else {
			type = (Java5Type)types.getVariableType(typeName);
			if (type==null) {
				throw new CodeGenerationException("Couldn't find a type named '"+typeName+"'");
			}
			if (type.getImport()!=null) {
				addImport(type.getImport(),ims);
			}
		}
	}
	
}


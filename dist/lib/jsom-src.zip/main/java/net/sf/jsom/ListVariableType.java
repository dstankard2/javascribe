package net.sf.jsom;

public interface ListVariableType extends VariableType {

	public CodeSnippet declare(String varName,String elementType) throws CodeGenerationException;

}

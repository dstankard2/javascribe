package net.sf.jsom.java5;

import java.util.List;

import net.sf.jsom.CodeGenerationException;

/**
 * Highest level base class for a piece of Java code.  Annotations and Java code 
 * snippets ultimately inherit from this class.
 * @author Dave
 *
 */
public interface Java5CodePart {

	/**
	 * Returns a String which implements this piece of code.
	 * @return Java code as a string.
	 */
	public String getCode() throws CodeGenerationException;
	
	public List<String> getImports() throws CodeGenerationException;
	
}

package net.sf.jsom;

/**
 * The standard JSOM exception class.  Represents an error encountered while building 
 * either the sourcecode object model or the sourcecode.
 * @author Dave
 *
 */
public class CodeGenerationException extends Exception {
	public static final long serialVersionUID = 123456789L;

	public CodeGenerationException() {
		super();
	}
	
	public CodeGenerationException(Throwable e) {
		super(e);
	}
	
	public CodeGenerationException(String s,Throwable e) {
		super(s,e);
	}
	
	public CodeGenerationException(String s) {
		super(s);
	}
	
}

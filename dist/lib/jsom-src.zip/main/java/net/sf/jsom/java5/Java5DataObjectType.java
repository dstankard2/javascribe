package net.sf.jsom.java5;

import java.util.HashMap;
import java.util.Map;

import net.sf.jsom.CodeGenerationException;
import net.sf.jsom.CodeSnippet;

public class Java5DataObjectType implements Java5CompatibleType {
	String pkg = null;
	String name = null;
	String className = null;
	Map<String,String> attributes = new HashMap<String,String>();
	
	public void addAttribute(String name,String type) {
		attributes.put(name, type);
	}
	
	public String getAttributeType(String name) {
		return attributes.get(name);
	}
	
	public void setPkg(String s) {
		pkg = s;
	}
	public void setName(String s) {
		name = s;
	}
	public void setClassName(String s) {
		className = s;
	}
	
	public String getImport() {
		return pkg+'.'+className;
	}

	public String getClassName() {
		return className;
	}

	public String getName() {
		return name;
	}
	
	public CodeSnippet instantiate(String varName,String value) throws CodeGenerationException {
		Java5CodeSnippet ret = new Java5CodeSnippet();
		
		
		
		return ret;
	}
	
	public CodeSnippet declare(String varName) {
		Java5CodeSnippet ret = new Java5CodeSnippet();
		
		ret.append(getClassName()+" "+varName+" = null;\n");
		ret.addImport(getImport());
		
		return ret;
	}
}

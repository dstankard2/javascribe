package net.sf.jsom.java5;

import net.sf.jsom.VariableType;

public interface Java5Type extends VariableType,Java5CompatibleType {

	public String getClassName();
	public String getImport();

}

package net.sf.jsom;

import java.util.HashMap;

public class VariableTypeResolver {
	HashMap<String,VariableType> types = new HashMap<String,VariableType>();
	
	public VariableType getVariableType(String name) {
		VariableType ret = null;
		
		if (name.indexOf("list")==0) {
			ret = types.get("list");
		} else if (name.indexOf("map")==0) {
			ret = types.get("map");
		} else {
			ret = types.get(name);
		}
		return ret;
	}
	
	public void addVariableType(VariableType type) {
		if (type!=null) {
			if (type.getName()==null)
				throw new IllegalArgumentException("VariableTypeResolver found a type with no name");
			types.put(type.getName(), type);
		}
	}
	
}

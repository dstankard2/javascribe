/*
 * Created on Jul 13, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.sf.jsom.java5;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import net.sf.jsom.CodeGenerationException;
import net.sf.jsom.VariableTypeResolver;
import net.sf.jsom.java5.Java5Annotation;
import net.sf.jsom.java5.Java5CodeSnippet;
import net.sf.jsom.java5.Java5CompatibleType;
import net.sf.jsom.java5.Java5DeclaredMethod;
import net.sf.jsom.java5.Java5SourceFile;
import net.sf.jsom.java5.NVPAnnotationArgument;

/**
 * @author DCS
 * 
 * Represents a JavaBean source file in Java 1.4.
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Java5DataObjectSourceFile extends Java5SourceFile {
    HashMap<String,Java5MemberDeclaration> properties = null;
    Java5Annotation xmlType = null;
    List<Object> jaxbPropertyList = null;
    
	public Java5DataObjectSourceFile(VariableTypeResolver c) { 
		super(c);
	    getPublicClass().addImplementedInterface("java.io.Serializable");
	    properties = new HashMap<String,Java5MemberDeclaration>();
	}
	
	public void addPropertyAnnotation(String property,Java5Annotation an) throws CodeGenerationException {
		Java5MemberDeclaration dec = null;
		
		dec = publicClass.getVariableDeclaration(property);
		dec.getAnnotations().add(an);
	}

	public void setXmlTypeName(String s) {
		NVPAnnotationArgument arg = null;

		if (xmlType==null) {
			xmlType = new Java5Annotation("javax.xml.bind.annotation.XmlType");
			getPublicClass().addAnnotation(xmlType);
			arg = new NVPAnnotationArgument("name",'\"'+s+'\"');
			xmlType.addArgument(arg);
		}
	}
	
	public void addXmlElementAnnotation(String property) {
		NVPAnnotationArgument arg = null;
		
		if (xmlType==null) {
			xmlType = new Java5Annotation("javax.xml.bind.annotation.XmlType");
			getPublicClass().addAnnotation(xmlType);
		}
		if (jaxbPropertyList==null) {
			jaxbPropertyList = new ArrayList<Object>();
			arg = new NVPAnnotationArgument("propOrder",jaxbPropertyList);
			xmlType.addArgument(arg);
		}
		jaxbPropertyList.add('\"'+property+'\"');
	}

	public void addJavaBeanProperty(String name,String type) throws CodeGenerationException {
	    Java5DeclaredMethod method = null;
	    Java5CodeSnippet code = null;
	    Java5CompatibleType acc = null;
	    
	    if (properties.get(name)!=null) {
	    	throw new CodeGenerationException("Tried to add field '"+name+"' twice");
	    }
	    Java5MemberDeclaration mem = new Java5MemberDeclaration(types);
	    mem.setName(name);
	    mem.setType(type);
	    properties.put(name,mem);
	    if (types.getVariableType(type)==null) {
	    	throw new CodeGenerationException("Illegal type specified: '"+type+"'");
	    }
	    publicClass.addMemberVariable(name,type,null);

	    method = new Java5DeclaredMethod(types);
	    method.setName("set"+Character.toUpperCase(name.charAt(0))+name.substring(1));
	    method.addArg(type,name);
	    acc = (Java5CompatibleType)types.getVariableType(type);
	    if (acc==null)
	    	throw new CodeGenerationException("Tried to add an attribute '"+name+"' of invalid type '"+type+"' to JavaBean.");
	    code = new Java5CodeSnippet();
	    code.append("this."+name+" = "+name+";\n");

	    method.setMethodBody(code);
	    publicClass.addMethod(method);

	    method = new Java5DeclaredMethod(this.types);
	    method.setName("get"+Character.toUpperCase(name.charAt(0))+name.substring(1));
	    method.setType(type);
	    code = new Java5CodeSnippet();
	    code.append("return "+name+";\n");
	    method.setMethodBody(code);
	    publicClass.addMethod(method);
	}
}

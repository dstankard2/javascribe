package net.sf.jsom.java5;

import java.util.ArrayList;
import java.util.List;

import net.sf.jsom.CodeGenerationException;
import net.sf.jsom.VariableTypeResolver;

public class Java5VariableDeclaration extends Java5MemberDeclaration implements Java5CodePart {
	String value = null;
	boolean isFinal = false;

	public Java5VariableDeclaration(VariableTypeResolver acc) {
		super(acc);
	}
	
	public List<String> getImports() throws CodeGenerationException {
		List<String> ret = new ArrayList<String>();
		
		Java5Util.addImport(type, ret, types);
		for(int i=0;i<annotations.size();i++) {
			Java5Util.appendImports(ret, annotations.get(i).getImports());
		}
		
		return ret;
	}
	
	public void addAnnotation(Java5Annotation a) {
		annotations.add(a);
	}

	public StringBuilder getSource() throws CodeGenerationException {
		return new StringBuilder(getCode());
	}
	
	public String getCode() throws CodeGenerationException {
		StringBuffer ret = null;
		Java5Annotation a = null;
		Java5CompatibleType acc = null;
		Java5CompatibleType elementAcc = null;
		
		ret = new StringBuffer();
		for(int i=0;i<annotations.size();i++) {
			a = annotations.get(i);
			ret.append(a.getCode());
		}
		
		// Temporary - If both static and final, then make it public
		if ((isStatic) && (isFinal)) {
			ret.append("public ");
		}
		if (isStatic) {
			ret.append("static ");
		}
		if (isFinal) {
			ret.append("final ");
		}
		acc = (Java5CompatibleType)types.getVariableType(type);
		if (type.indexOf("list/")==0) {
			elementAcc = (Java5CompatibleType)types.getVariableType(type.substring(5));
			ret.append(acc.getClassName()+'<'+elementAcc.getClassName()+"> "+name);
		} else if (type.indexOf("map-")==0) {
			elementAcc = (Java5CompatibleType)types.getVariableType(type.substring(4));
			ret.append(acc.getClassName()+"<String,"+elementAcc.getClassName()+"> "+name);
		} else {
			ret.append(acc.getClassName()+' '+name);
		}
		if (value!=null) {
			ret.append(" = ").append(value);
		}
		ret.append(';');
		return ret.toString();
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public Java5Type getVariableType() {
		return (Java5Type)types.getVariableType(type);
	}

	public boolean isStatic() {
		return isStatic;
	}

	public void setStatic(boolean isStatic) {
		this.isStatic = isStatic;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public boolean isFinal() {
		return isFinal;
	}

	public void setFinal(boolean isFinal) {
		this.isFinal = isFinal;
	}
	
}


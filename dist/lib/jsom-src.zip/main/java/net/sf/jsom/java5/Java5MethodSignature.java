/*
 * Created on Mar 11, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.sf.jsom.java5;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import net.sf.jsom.CodeGenerationException;
import net.sf.jsom.VariableTypeResolver;

/**
 * @author DCS
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Java5MethodSignature extends Java5MemberDeclaration {
//	private List<Java5Annotation> annotations = new ArrayList<Java5Annotation>();
	List<String> thrownExceptions = new ArrayList<String>();
	HashMap<String,Java5MethodParameter> args = new HashMap<String,Java5MethodParameter>();
	List<String> argNames = new ArrayList<String>();

	public void addAnnotation(Java5Annotation a) {
		annotations.add(a);
	}
	
	public List<String> getImports() throws CodeGenerationException {
		List<String> ret = new ArrayList<String>();
		List<String> append = null;
		Java5MethodParameter param = null;
		Iterator<Java5MethodParameter> it = null;
		
		// Return imports for return type, exceptions, annotations, arguments
		if (type!=null) {
			Java5Util.addImport(type, ret, types);
		}
		for(int i=0;i<thrownExceptions.size();i++) {
			Java5Util.addImport(thrownExceptions.get(i), ret, types);
		}
		for(int i=0;i<annotations.size();i++) {
			append = annotations.get(i).getImports();
			for(int i2=0;i2<append.size();i2++) {
				Java5Util.addImport(append.get(i2), ret);
			}
		}
		it = args.values().iterator();
		while(it.hasNext()) {
			param = it.next();
			Java5Util.appendImports(ret, param.getImports());
		}
		
		return ret; 
	}

	public Java5MethodSignature(VariableTypeResolver acc) {
		super(acc);
		args = new HashMap<String,Java5MethodParameter>();
		thrownExceptions = new ArrayList<String>();
		argNames = new ArrayList<String>();
		annotations = new ArrayList<Java5Annotation>();
	}

	public void addArg(String type,String name) throws CodeGenerationException {
		Java5MethodParameter p = null;
		
		p = new Java5MethodParameter(types);
		p.setName(name);
		p.setType(type);
		args.put(name,p);
		argNames.add(name);
	}

	public void addArg(Java5MethodParameter p) {
		args.put(p.getName(),p);
		argNames.add(p.getName());
	}

	/**
	 * @return Returns the thrownExceptions.
	 */
	public List<String> getThrownExceptions() {
		return thrownExceptions;
	}
	/**
	 * @param thrownExceptions The thrownExceptions to set.
	 */
	public void setThrownExceptions(List<String> thrownExceptions) {
		this.thrownExceptions = thrownExceptions;
	}
	public void addThrownException(String ex) throws CodeGenerationException {
		if (!thrownExceptions.contains(ex)) {
			thrownExceptions.add(ex);
		}
	}

	/**
	 * @return Returns the argNames.
	 */
	public List<String> getArgNames() {
		return argNames;
	}

	public Java5MethodParameter getArg(String argName) {
		return args.get(argName);
	}
	
	public StringBuilder getSource() throws CodeGenerationException {
		StringBuilder ret = new StringBuilder();
		
		if (types==null) throw new CodeGenerationException("Cannot get source code for a method when no ProcessorTypesAccessor is supplied.");
		
		ret.append(getMethodDeclarationText());
		ret.append(";\n");
		
		return ret;
	}
	
	protected String getMethodDeclarationText() throws CodeGenerationException {
		StringBuffer buf = new StringBuffer();
		Java5CompatibleType typeAcc = null;
		Java5MethodParameter param = null;
		Java5Annotation ann = null;

		List<String> l = null;
		String type = null;
		String argName = null;
		String val = null;

		for(int i=0;i<annotations.size();i++) {
			ann = annotations.get(i);
			buf.append(ann.getCode()).append('\n');
		}

		buf.append("  "+accessLevel+" ");
		if (this instanceof Java5DeclaredMethod) {
			Java5DeclaredMethod meth = (Java5DeclaredMethod)this;
			if (meth.isStatic()) {
				buf.append("static ");
			}
		}
		if (!(this instanceof Java5DeclaredMethod)) { // Abstract method
			buf.append("abstract ");
		}
		if (this instanceof Java5ClassConstructor) {
		    // no-op
		} else if (getType()==null) {
			buf.append("void ");
		} else if (getType()!=null) {
			if (getType().indexOf("list/")==0) {
				String elementTypeName = null;
				Java5CompatibleType elementAcc = null;
				elementTypeName = getType().substring(5);
				elementAcc = (Java5CompatibleType)types.getVariableType(elementTypeName);
				buf.append("java.util.List<"+elementAcc.getClassName()+"> ");
			} else if (getType().indexOf("map-")==0) {
				String elementTypeName = getType().substring(4);
				Java5CompatibleType elementAcc = (Java5CompatibleType)types.getVariableType(elementTypeName);
				buf.append("java.util.Map<String,"+elementAcc.getClassName()+"> ");
			} else {
				typeAcc = (Java5CompatibleType)types.getVariableType(getType());
				buf.append(typeAcc.getClassName()+' ');
			}	
		}
		buf.append(getName()+"(");
		List<String> l2 = getArgNames();
		for(int i=0;i<l2.size();i++) {
			argName = (String)l2.get(i);
			param = args.get(argName);
			if (i>0) buf.append(',');
			buf.append(param.getSource());
		}
		buf.append(')');
		l = this.getThrownExceptions();
		for(int i=0;i<l.size();i++) {
			if (i==0) {
				buf.append(" throws ");
			} else {
				buf.append(',');
			}
			val = (String)l.get(i);
			try {
				Java5CompatibleType exType = (Java5CompatibleType)types.getVariableType(val);
				if (exType.getImport()!=null) type = exType.getImport();
				else type = exType.getClassName();
				buf.append(type);
			} catch(Exception e) {
				throw new CodeGenerationException("Invalid exception type '"+val+"' specified");
			}
		}
		return buf.toString();
	}

	public String getAccessLevel() {
		return accessLevel;
	}

	public void setAccessLevel(String accessLevel) {
		this.accessLevel = accessLevel;
	}
}

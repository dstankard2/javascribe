package net.sf.jsom;

/**
 * @author Dave
 *
 */
public interface VariableType {

	public String getName();
	public CodeSnippet instantiate(String varName,String value) throws CodeGenerationException;
	public CodeSnippet declare(String varName) throws CodeGenerationException;
	
}

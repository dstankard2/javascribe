package net.sf.jsom.java5;

import java.util.ArrayList;
import java.util.List;

import net.sf.jsom.CodeGenerationException;
import net.sf.jsom.VariableTypeResolver;

/**
 * A Java 5 method parameter has a type and name, and can have 0 or more annotations as well.
 * @author Dave
 *
 */
public class Java5MethodParameter {
	String name = null;
	String type = null;
	List<Java5Annotation> annotations = new ArrayList<Java5Annotation>();
	VariableTypeResolver types = null;
	
	public List<String> getImports() throws CodeGenerationException {
		ArrayList<String> ret = new ArrayList<String>();
		Java5Annotation ann = null;
		
		Java5Util.addImport(type, ret, types);
		for(int i=0;i<annotations.size();i++) {
			ann = annotations.get(i);
			Java5Util.appendImports(ret, ann.getImports());
		}
		
		return ret;
	}
	
	public Java5MethodParameter(VariableTypeResolver acc) {
		types = acc;
	}
	
	public Java5MethodParameter(VariableTypeResolver acc,String name,String type) {
		types = acc;
		this.name = name;
		this.type = type;
	}
	
	public void addAnnotation(Java5Annotation a) {
		annotations.add(a);
	}

	public String getSource() throws CodeGenerationException {
		StringBuffer ret = null;
		Java5Annotation a = null;
		Java5CompatibleType acc = null;
		Java5CompatibleType elementAcc = null;
		
		ret = new StringBuffer();
		for(int i=0;i<annotations.size();i++) {
			a = annotations.get(i);
			ret.append(a.getCode());
		}
		
		acc = (Java5CompatibleType)types.getVariableType(type);
		if (type.indexOf("list/")==0) {
			elementAcc = (Java5CompatibleType)types.getVariableType(type.substring(5));
			ret.append(acc.getClassName()+'<'+elementAcc.getClassName()+"> "+name);
		} else if (type.indexOf("map-")==0) {
			elementAcc = (Java5CompatibleType)types.getVariableType(type.substring(4));
			ret.append(acc.getClassName()+"<String,"+elementAcc.getClassName()+"> "+name);
		} else {
			ret.append(acc.getClassName()+' '+name);
		}
		
		return ret.toString();
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
}

package net.sf.jsom.java5;

import java.io.IOException;
import java.io.Reader;

public class Java5SourceFileReader {

	public Java5SourceFile readSourceFile(Reader reader) {
		Java5SourceFile ret = null;
		
		// Read package statement
		
		return ret;
	}

	protected String readNextNonBlankLine(Reader reader) throws IOException {
		String ret = null;
		
		ret = readLine(reader);
		while(ret.length()==0) {
			ret = readLine(reader);
		}
		return ret;
	}
	
	protected String readLine(Reader reader) throws IOException {
		StringBuilder build = new StringBuilder();
		char c = readChar(reader);

		while(c!='\n') {
			build.append(c);
		}
		
		return build.toString();
	}
	
	protected StringBuilder findMethodBody(Reader source) throws IOException {
		StringBuilder ret = new StringBuilder();
		char c;
		int numNesting = 0;
		
		c = readChar(source);
		while((c!='}') || (numNesting>0)) {
			ret.append(c);
			c = readChar(source);
		}
		
		return ret;
	}
	
	protected char readChar(Reader reader) throws IOException {
		char ret;
		int read = reader.read();
		
		if (read<0) {
			throw new IOException("Encountered unexpected end of file.");
		}
		ret = (char)read;

		return ret;
	}
	
}

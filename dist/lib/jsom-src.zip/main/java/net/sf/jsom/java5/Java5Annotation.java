package net.sf.jsom.java5;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a Java 5 annotation.  It consists of a class and either a value or a 
 * list of annotation arguments.  Which one is used and allowed depends on which 
 * constructor you use to instantiate an instance.
 * The class name specified in the constructor must be the fully-qualified class 
 * name.  It will be used to determine what import to add to the container Java 5 
 * source file.
 * @author Dave
 */
public class Java5Annotation implements Java5CodePart,AnnotationArgument {
	List<AnnotationArgument> args = null;
	String annotationClass = null;
	String stringValue = null;
	List<Java5Annotation> nestedAnnotations = null;
	
	Java5Annotation annValue = null;
	
	public void addArgument(AnnotationArgument arg) {
		if (args==null)
			throw new IllegalStateException("This annotation cannot take an argument.");
		args.add(arg);
	}
	
	public Java5Annotation(String className) {
		args = new ArrayList<AnnotationArgument>();
		annotationClass = className;
	}
	
	public Java5Annotation(String className,boolean nestedAnnotations) {
		if (nestedAnnotations) {
			this.nestedAnnotations = new ArrayList<Java5Annotation>();
		}
		annotationClass = className;
	}
	
	public void addNestedAnnotation(Java5Annotation an) {
		if (nestedAnnotations==null)
			throw new RuntimeException("Illegal operation");
		nestedAnnotations.add(an);
	}
	
	public Java5Annotation(String className,String value) {
		annotationClass = className;
		this.stringValue = value;
	}
	
	public List<String> getImports() {
		List<String> ret = new ArrayList<String>();
		List<String> append = null;
		
		ret.add(annotationClass);
		if (args!=null) {
			for(int i=0;i<args.size();i++) {
				append = args.get(i).getImports();
				ret.addAll(append);
			}
		}
		if (nestedAnnotations!=null) {
			for(int i=0;i<nestedAnnotations.size();i++) {
				append = nestedAnnotations.get(i).getImports();
				ret.addAll(append);
			}
		}
		
		return ret;
	}
	
	public String getCode() {
		StringBuffer build = new StringBuffer();
		AnnotationArgument arg = null;
		Java5Annotation an = null;
		
		build.append('@');
		build.append(annotationClass);
		
		if (stringValue!=null) {
			build.append('(').append(stringValue).append(')');
		} else if (nestedAnnotations!=null) {
			build.append("({");
			for(int i=0;i<nestedAnnotations.size();i++) {
				if (i>0) build.append(',');
				an = nestedAnnotations.get(i);
				build.append(an.getCode());
			}
			build.append("})");
		} else if (args.size()>0) {
			build.append('(');
			for(int i=0;i<args.size();i++) {
				arg = args.get(i);
				if (i>0) build.append(',');
				build.append(arg.getCode());
			}
			build.append(')');
		}
		build.append('\n');
		return build.toString();
	}

}


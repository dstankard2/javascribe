package net.sf.jsom.java5;

import java.util.ArrayList;
import java.util.List;

import net.sf.jsom.CodeGenerationException;
import net.sf.jsom.VariableTypeResolver;

public class Java5MemberDeclaration {

	protected List<Java5Annotation> annotations = new ArrayList<Java5Annotation>();
	protected String name = null;
	protected String accessLevel = "public";
	protected String type = null;
	protected VariableTypeResolver types = null;
	protected boolean isStatic = false;
	
	public Java5MemberDeclaration(VariableTypeResolver acc) {
		this.types = acc;
	}
	
	List<String> getImports() throws CodeGenerationException {
		ArrayList<String> ret = new ArrayList<String>();
		
		Java5CompatibleType t = (Java5CompatibleType)types.getVariableType(type);
		if (t.getImport()!=null)
			ret.add(t.getImport());
		for(Java5Annotation an : annotations) {
			Java5Util.appendImports(ret, an.getImports());
		}
		
		return ret;
	}
	
	public boolean isStatic() {
		return isStatic;
	}
	public void setStatic(boolean isStatic) {
		this.isStatic = isStatic;
	}
	public List<Java5Annotation> getAnnotations() {
		return annotations;
	}
	public void setAnnotations(List<Java5Annotation> annotations) {
		this.annotations = annotations;
	}
	public VariableTypeResolver getTypes() {
		return types;
	}
	public void setTypes(VariableTypeResolver types) {
		this.types = types;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getAccessLevel() {
		return accessLevel;
	}
	public void setAccessLevel(String accessLevel) {
		this.accessLevel = accessLevel;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public StringBuilder getSource() throws CodeGenerationException {
		StringBuilder build = new StringBuilder();

		if (types==null) throw new CodeGenerationException("Cannot get source code for a method when no ProcessorTypesAccessor is supplied.");

		for(Java5Annotation an : annotations) {
			build.append(an.getCode()).append('\n');
		}
		
		if (accessLevel!=null) {
			build.append(accessLevel).append(' ');
		}
		if (isStatic) {
			build.append("static ");
		}
		Java5CompatibleType typeAcc = null;
		typeAcc = (Java5CompatibleType)types.getVariableType(getType());
		build.append(typeAcc.getClassName()+' ');
		build.append(name).append(";\n");
		
		return build;
	}
	
}


/*
 * Created on Mar 5, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.sf.jsom.java5;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import net.sf.jsom.CodeGenerationException;
import net.sf.jsom.VariableTypeResolver;

/**
 * @author User
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Java5ClassDefinition {
	List<Java5Annotation> annotations = new ArrayList<Java5Annotation>();
	List<Java5MethodSignature> methods = new ArrayList<Java5MethodSignature>();
	HashMap<String,Java5MemberDeclaration> memberVariables = new HashMap<String,Java5MemberDeclaration>();
	
	HashMap<String,String> staticVariables = new HashMap<String,String>();
	String className = null;
	String superClass = null;
	List<String> implementedInterfaces = new ArrayList<String>();
	boolean isInterface = false;
	boolean isAbstract = false;
	Java5SourceFile owner = null;
	VariableTypeResolver types = null;
	Java5CodeSnippet staticBlock = null;

	public List<String> getMethodNames() {
		List<String> ret = new ArrayList<String>();
		
		for(Java5MethodSignature s : methods) {
			ret.add(s.getName());
		}
		
		return ret;
	}
	
	public Java5MemberDeclaration getVariableDeclaration(String s) {
		return memberVariables.get(s);
	}
	
	public void addAnnotation(Java5Annotation ann) {
		annotations.add(ann);
	}
	
	public void setStaticBlock(Java5CodeSnippet code) {
	    staticBlock = code;
	}

	public Java5CodeSnippet getStaticBlock() { return staticBlock; }
	
	public void addStaticMemberVariable(String name,String type,String value) {
		Java5MemberDeclaration dec = new Java5MemberDeclaration(types);
		dec.setName(name);
		dec.setType(type);
		dec.setStatic(true);
	    memberVariables.put(name,dec);
	}

	public void addMemberVariable(String name,String type,String value) {
		Java5MemberDeclaration dec = new Java5MemberDeclaration(types);
		dec.setName(name);
		dec.setType(type);
		dec.setStatic(false);
	    memberVariables.put(name,dec);
	}
	
	public void addMemberVariable(Java5MemberDeclaration dec) {
		memberVariables.put(dec.getName(), dec);
	}
	
	public VariableTypeResolver getTypes() {
		return types;
	}
	Java5ClassDefinition(Java5SourceFile o) {
		types = o.getVariableTypeResolver();
		owner = o;
	}

	public void addAbstractMethod(Java5MethodSignature m) {
		if (!isInterface) throw new IllegalArgumentException("Can only add abstract methods to interfaces.");
		addMethod(m);
	}

	public void addMethod(Java5MethodSignature m) {
		methods.add(m);
	}

	public void addImplementedInterface(String interfaceName) {
		if (!implementedInterfaces.contains(interfaceName)) {
			implementedInterfaces.add(interfaceName);
		}
	}
	public Java5MethodSignature getDeclaredMethod(String name) {
		Java5MethodSignature ret = null;
		
		for(int i=0;(i<methods.size()) && (ret==null);i++) {
			ret = (Java5MethodSignature)methods.get(i);
			if (!ret.getName().equals(name)) {
				ret = null;
			}
		}
		
		return ret;
	}
	
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getSuperClass() {
		return superClass;
	}
	public void setSuperClass(String superClass) {
		this.superClass = superClass;
	}

	public List<String> getImports() throws CodeGenerationException {
		List<String> ret = new ArrayList<String>();

		// Add imports for instance variables, static variables, methods, 
		// annotations, static block
		
		Iterator<Java5MemberDeclaration> it = this.memberVariables.values().iterator();
		while(it.hasNext()) {
			Java5MemberDeclaration dec = it.next();
			Java5Util.appendImports(ret, dec.getImports());
		}
		Iterator<String> staticVarTypes = this.staticVariables.values().iterator();
		while(staticVarTypes.hasNext()) {
			String s = staticVarTypes.next();
			Java5Util.addImport(s, ret, types);
		}
		for(int i=0;i<methods.size();i++) {
			Java5MethodSignature sig = null;
			sig = methods.get(i);
			Java5Util.appendImports(ret, sig.getImports());
		}
		for(int i=0;i<annotations.size();i++) {
			Java5Util.appendImports(ret, annotations.get(i).getImports());
		}
		if (staticBlock!=null) {
			Java5Util.appendImports(ret, staticBlock.getRequiredImports());
		}

		return ret;
	}
	
	public StringBuffer getSource() throws CodeGenerationException {
		StringBuffer ret = new StringBuffer();
		String value = null;
		Java5MethodSignature method = null;
		
		// Add imports for instance variables, static variables, methods, 
		// annotations, static block

		for(int i=0;i<annotations.size();i++) {
			ret.append(annotations.get(i).getCode());
		}
		
		ret.append("\npublic ");
		if (isAbstract()) ret.append("abstract ");
		if (isInterface) {
			ret.append("interface "+className+' ');
			if (superClass!=null) {
				ret.append("extends ").append(superClass);
			}
/*	// Pretty sure we don't need to worry about implemented interfaces
			if (implementedInterfaces.size()>0) {
				ret.append("extends ");
				for(int i=0;i<implementedInterfaces.size();i++) {
					if (i>0) ret.append(',');
					value = (String)implementedInterfaces.get(i);
					ret.append(value);
				}
			}
			*/
			ret.append(" {\n");
		} else {
			ret.append("class "+className+' ');
			if (superClass!=null) {
				ret.append("extends "+superClass+' ');
			}
			if (implementedInterfaces.size()>0) {
				ret.append("implements ");
				for(int i=0;i<implementedInterfaces.size();i++) {
					if (i>0) ret.append(',');
					value = (String)implementedInterfaces.get(i);
					ret.append(value);
				}
			}
			ret.append(" {\n\n");
		}

		// Add member variables
		Iterator<?> it = memberVariables.keySet().iterator();
		while(it.hasNext()) {
		    String name = (String)it.next();
		    Java5MemberDeclaration dec = (Java5MemberDeclaration)memberVariables.get(name);
		    ret.append(dec.getSource().toString());
		    ret.append('\n');
		}
		
		// Add static member variables
		it = staticVariables.keySet().iterator();
		while(it.hasNext()) {
		    String name = (String)it.next();
		    String type = (String)staticVariables.get(name);
		    Java5CompatibleType javaType = (Java5CompatibleType)types.getVariableType(type);
		    if (javaType.getImport()==null) 
		        ret.append("static "+javaType.getClassName()).append(' ').append(name).append(";\n");
		    else 
		        ret.append("static "+javaType.getImport()).append(' ').append(name).append(";\n");
		}
		
		for(int i=0;i<methods.size();i++) {
			method = methods.get(i);
			ret.append(method.getSource());
		}
		
		// Add static block
		if (staticBlock!=null) {
		    ret.append("static {\n")
		    	.append(staticBlock.getSource().toString())
		    	.append("}\n");
		}
		
		ret.append("\n}\n");
		
		return ret;
	}

	public boolean isAbstract() {
		return isAbstract;
	}
	public void setAbstract(boolean isAbstract) {
		this.isAbstract = isAbstract;
	}
	public boolean isInterface() {
		return isInterface;
	}
	public void setInterface(boolean isInterface) {
		this.isInterface = isInterface;
	}

}

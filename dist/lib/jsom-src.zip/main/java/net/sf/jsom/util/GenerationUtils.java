package net.sf.jsom.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import net.sf.jsom.CodeGenerationException;
import net.sf.jsom.SourceFile;
import net.sf.jsom.VariableTypeResolver;
import net.sf.jsom.java5.Java5TypeImpl;

public class GenerationUtils {

	public static void writeFile(SourceFile src) throws IOException,CodeGenerationException {
		File f = null;
		FileWriter writer = null;
		
		try {
			f = new File(src.getPath());
			f.getParentFile().mkdirs();
			writer = new FileWriter(f);
			writer.write(src.getSource().toString());
		} finally {
			if (writer!=null)
				try {
					writer.close();
				} catch(Exception e) {
				}
		}
	}
	
	/**
	 * Populates the specified resolver with several basic Java types including integer, 
	 * long, string, list.
	 * @param r
	 */
	public static void populateDefaultJavaTypes(VariableTypeResolver r) {
		Java5TypeImpl type = null;
		
		type = new Java5TypeImpl("integer",null,"Integer");
		r.addVariableType(type);
		type = new Java5TypeImpl("string",null,"String");
		r.addVariableType(type);
	}

}


package net.sf.jsom.java5;

import java.util.ArrayList;
import java.util.List;

import net.sf.jsom.CodeGenerationException;
import net.sf.jsom.CodeSnippet;

/**
 * @author Dave
 *
 * A Java5CodeSnippet represents a piece of code that is to become 
 * part of a method or some other code execution construct (such as 
 * a try/catch block).
 */
public class Java5CodeSnippet implements Java5CompatibleCodeSnippet {
	private List<String> requiredImports = null;
	private List<Java5CodePart> code = null;
	
	public String getSource() throws CodeGenerationException {
		StringBuffer ret = new StringBuffer();
		Java5CodePart p = null;
		
		for(int i=0;i<code.size();i++) {
			p = code.get(i);
			ret.append(p.getCode());
		}
		
		return ret.toString();
	}

	public Java5CodeSnippet append(String s) {
		Java5Code c = null;
		Java5CodePart p = null;
		
		if (code.size()>0) {
			p = code.get(code.size()-1);
			if (p instanceof Java5Code) {
				c = (Java5Code)p;
				c.append(s);
			} else {
				c = new Java5Code(s);
				code.add(c);
			}
		} else {
			c = new Java5Code(s);
			code.add(c);
		}
		return this;
	}
	
	public Java5CodeSnippet append(char ch) {
		Java5Code c = null;
		Java5CodePart p = null;
		
		if (code.size()>0) {
			p = code.get(code.size()-1);
			if (p instanceof Java5Code) {
				c = (Java5Code)p;
				c.append(ch);
			}
		} else {
			c = new Java5Code(""+ch);
			code.add(c);
		}
		return this;
	}
	
	public Java5CodeSnippet append(Java5CodePart p) {
		code.add(p);
		return this;
	}
		
	public Java5CodeSnippet() { 
		requiredImports = new ArrayList<String>();
		code = new ArrayList<Java5CodePart>();
	}
	
	// Returns a non-null list of imports.
	public List<String> getRequiredImports() {
		return requiredImports;
	}
	
	public void addImport(String s) {
		if (s!=null) {
			if (!requiredImports.contains(s)) {
				requiredImports.add(s);
			}
		}
	}
	
	// Merge two code snippets together
	public void merge(CodeSnippet other) throws CodeGenerationException {
		List<String> imports = null;
		String s = null;
		Java5CompatibleCodeSnippet v = null;
		
		if (other instanceof Java5CompatibleCodeSnippet) {
			Java5Code c = null;
			
			v = (Java5CompatibleCodeSnippet)other;
//			source.append(other.getSource());
			if (other!=null) {
				imports = v.getRequiredImports();
				for(int i=0;i<imports.size();i++) {
					s = imports.get(i);
					addImport(s);
				}
			}
			c = new Java5Code(v.getSource());
			code.add(c);
		}
		else if (other instanceof Java5CompatibleCodeSnippet) {
			Java5CompatibleCodeSnippet o = (Java5CompatibleCodeSnippet)other;
			Java5Code c = null;
			String im = null;
			
			c = new Java5Code(o.getSource());
			code.add(c);
			imports = o.getRequiredImports();
			for(int i=0;i<imports.size();i++) {
				im = imports.get(i);
				if (!requiredImports.contains(im)) {
					requiredImports.add(im);
				}
			}
		}
	}
}


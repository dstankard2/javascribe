
drop table tb_user;
create table tb_user (
user_id int auto_increment primary key,
client_id int,
role_id int,
status int,
first_name varchar(64),
last_name varchar(64),
email varchar(128)
);


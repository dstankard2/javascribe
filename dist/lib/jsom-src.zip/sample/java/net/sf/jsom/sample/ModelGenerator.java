package net.sf.jsom.sample;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import net.sf.jsom.SourceFile;
import net.sf.jsom.VariableTypeResolver;
import net.sf.jsom.java5.Java5ClassDefinition;
import net.sf.jsom.java5.Java5SourceFile;
import net.sf.jsom.java5.Java5TypeImpl;
import net.sf.jsom.sample.configuration.EntityConfig;
import net.sf.jsom.sample.configuration.ModelConfig;
import net.sf.jsom.sample.database.TableInfo;
import net.sf.jsom.util.GenerationUtils;

/**
 * The JSOM sample application reads some fairly simple XML configuration 
 * @author Dave
 *
 */
public class ModelGenerator {

	public static void main(String args[]) {
		try {
			runProgram(args);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void runProgram(String args[]) throws Exception {
		File f = null;
		FileInputStream fin = null;
		
		// Objects needed to find DB info and configuration.
		ModelConfig cfg = null;
		DatabaseObjectNameResolver resolver = null;
		Connection conn = null;
		EntityConfig entity = null;
		List<EntityConfig> entities = null;
		TableMetadataProcessor metadata = null;
		TableInfo table = null;
		
		// JSOM objects needed for code generation
		VariableTypeResolver types = null;
		List<SourceFile> files = null; // List of files that we generate
		Java5SourceFile daoFactory = null;
		SourceFile sourceFile = null;
		
		Java5SourceFile ejbFile = null;
		Java5SourceFile daoFile = null;
		
		files = new ArrayList<SourceFile>();
		f = new File("C:\\personal\\sf_workspace\\JSOM\\sample\\xml\\config.xml");
		fin = new FileInputStream(f);
		cfg = readConfiguration(fin);
		System.out.println("Found configuration.");
		resolver = getDatabaseObjectNameResolver(cfg.getDbObjectNameResolver());
		types = new VariableTypeResolver();
		GenerationUtils.populateDefaultJavaTypes(types);
		populateCustomJavaTypes(types);
		conn = getDbConnection(cfg.getJdbcUrl(),cfg.getJdbcDriver(),cfg.getDbUser(),cfg.getDbPassword());
		daoFactory = createDaoFactory(cfg,types);
		metadata = getTableMetadataProcessor(cfg.getMetadataProcessor());
		entities = cfg.getEntityConfig();
		daoFactory = generateDaoFactory(cfg,types);
		files.add(daoFactory);

		addRelevantTypes(types,cfg,resolver);
		
		for(int i=0;i<entities.size();i++) {
			entity = entities.get(i);
			table = metadata.readTableData(entity, conn);
			ejbFile = EjbGenerator.createEjb(table,entity,cfg,resolver,types);
			files.add(ejbFile);
			daoFile = DaoGenerator.createDao(table, entity, cfg, resolver, types);
			files.add(daoFile);
		}
		
		// Write source files.
		for(int i=0;i<files.size();i++) {
			sourceFile = files.get(i);
			GenerationUtils.writeFile(sourceFile);
		}
	}

	private static void populateCustomJavaTypes(VariableTypeResolver types) {
		Java5TypeImpl type = null;
		
		type = new Java5TypeImpl("EntityManager","javax.persistence.EntityManager","EntityManager");
		types.addVariableType(type);
	}
	
	private static void addRelevantTypes(VariableTypeResolver res,ModelConfig cfg,DatabaseObjectNameResolver r) {
		List<EntityConfig> entities = null;
		EntityConfig en = null;
		Java5TypeImpl type = null;
		String cl = null;
		String im = null;
		
		entities = cfg.getEntityConfig();
		for(int i=0;i<entities.size();i++) {
			en = entities.get(i);
			cl = r.getJavaBeanName(en.getTableName());
			im = cfg.getEjbPackage()+'.'+cl;
			type = new Java5TypeImpl(cl,im,cl);
			res.addVariableType(type);
		}
	}
	
	private static Java5SourceFile generateDaoFactory(ModelConfig cfg,VariableTypeResolver types) {
		Java5SourceFile ret = null;
		Java5ClassDefinition def = null;
		
		ret = new Java5SourceFile(types);
		ret.setSourceRootPath(cfg.getSourceRoot());
		ret.setPackageName(cfg.getDaoPackage());
		def = ret.getPublicClass();
		def.setClassName("EjbDaoFactory");
		
		return ret;
	}
	
	private static Java5SourceFile createDaoFactory(ModelConfig cfg,VariableTypeResolver res) {
		Java5SourceFile ret = null;
		
		ret = new Java5SourceFile(res);
		
		return ret;
	}
	
	private static Connection getDbConnection(String url,String driver,String user,String pwd) throws SQLException,ClassNotFoundException,InstantiationException,IllegalAccessException {
		Connection ret = null;
		Driver drv = null;
		Class<?> cl = null;
		
		cl = Class.forName(driver);
		drv = (Driver)cl.newInstance();
		DriverManager.registerDriver(drv);

		ret = DriverManager.getConnection(url, user, pwd);
		
		return ret;
	}
	
	private static TableMetadataProcessor getTableMetadataProcessor(String className) throws ClassNotFoundException,InstantiationException,IllegalAccessException {
		TableMetadataProcessor ret = null;
		Class<?> cl = null;
		
		cl = Class.forName(className);
		ret = (TableMetadataProcessor)cl.newInstance();
		
		return ret;
	}
	
	private static DatabaseObjectNameResolver getDatabaseObjectNameResolver(String className) throws ClassNotFoundException,InstantiationException,IllegalAccessException {
		DatabaseObjectNameResolver ret = null;
		Class<?> cl = null;
		
		cl = Class.forName(className);
		ret = (DatabaseObjectNameResolver)cl.newInstance();
		
		return ret;
	}
	
	private static ModelConfig readConfiguration(InputStream in) throws JAXBException {
		ModelConfig ret = null;
		JAXBContext ctx = null;
		Unmarshaller um = null;
		
		ctx = JAXBContext.newInstance("net.sf.jsom.sample.configuration");
		um = ctx.createUnmarshaller();
		ret = (ModelConfig)um.unmarshal(in);

		return ret;
	}
	
}


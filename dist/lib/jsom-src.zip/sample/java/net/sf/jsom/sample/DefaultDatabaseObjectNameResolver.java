package net.sf.jsom.sample;

public class DefaultDatabaseObjectNameResolver implements DatabaseObjectNameResolver {

	public String getJavaBeanName(String tableName) {
		String ret = null;
		
		ret = "User";
		
		return ret;
	}

	public String getJavaBeanPropertyName(String tableFieldName) {
		StringBuilder build = new StringBuilder();
		int index = 0;
		int start = 0;
		
		tableFieldName = tableFieldName.toLowerCase();
		index = tableFieldName.indexOf("_");
		if (index>=0) build.append(tableFieldName.substring(0, index));
		else build.append(tableFieldName);
		
		while(index>=0) {
			start = index+1;
			index = tableFieldName.indexOf("_", start+1);
			if (index>=0) {
				build.append(Character.toUpperCase(tableFieldName.charAt(start)))
				     .append(tableFieldName.substring(start+1, index));
			} else {
				build.append(Character.toUpperCase(tableFieldName.charAt(start)))
				     .append(tableFieldName.substring(start+1));
			}
		}
		
		
		return build.toString();
	}

}

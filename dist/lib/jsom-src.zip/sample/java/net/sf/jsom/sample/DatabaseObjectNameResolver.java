package net.sf.jsom.sample;

public interface DatabaseObjectNameResolver {
	
	public String getJavaBeanName(String tableName);
	public String getJavaBeanPropertyName(String tableFieldName);
	
}

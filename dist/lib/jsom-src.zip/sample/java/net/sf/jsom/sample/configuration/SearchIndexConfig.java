package net.sf.jsom.sample.configuration;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="searchIndex",propOrder={"field","update"
})
public class SearchIndexConfig {

	@XmlAttribute
	private String delete = null;
	
	@XmlAttribute
	private String select = null;
	
	@XmlAttribute
	private String multiple = "false";
	
	@XmlAttribute
	private String name = null;
	
	@XmlElement(name="field")
	private List<String> field = new ArrayList<String>();

	@XmlElement(name="update")
	private List<UpdateConfig> update = new ArrayList<UpdateConfig>();

	public String getDelete() {
		return delete;
	}

	public void setDelete(String delete) {
		this.delete = delete;
	}

	public List<String> getField() {
		return field;
	}

	public void setField(List<String> field) {
		this.field = field;
	}

	public String getSelect() {
		return select;
	}

	public void setSelect(String select) {
		this.select = select;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMultiple() {
		return multiple;
	}

	public void setMultiple(String multiple) {
		this.multiple = multiple;
	}

	public List<UpdateConfig> getUpdate() {
		return update;
	}

	public void setUpdate(List<UpdateConfig> update) {
		this.update = update;
	}
	
}

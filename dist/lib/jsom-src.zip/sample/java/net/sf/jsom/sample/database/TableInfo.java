package net.sf.jsom.sample.database;

import java.util.HashMap;

public class TableInfo {

	private HashMap<String,String> fields = null;
	private String tableName = null;
	private String pkField = null;

	public HashMap<String, String> getFields() {
		return fields;
	}
	public void setFields(HashMap<String, String> fields) {
		this.fields = fields;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getPkField() {
		return pkField;
	}
	public void setPkField(String pkField) {
		this.pkField = pkField;
	}
	
}

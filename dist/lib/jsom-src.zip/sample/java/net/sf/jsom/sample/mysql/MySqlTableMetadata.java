package net.sf.jsom.sample.mysql;

import java.sql.Connection;
import java.util.HashMap;

import net.sf.jsom.sample.TableMetadataProcessor;
import net.sf.jsom.sample.configuration.EntityConfig;
import net.sf.jsom.sample.database.TableInfo;

public class MySqlTableMetadata implements TableMetadataProcessor {

	public TableInfo readTableData(EntityConfig entity,Connection db) {
		TableInfo ret = null;
		
		ret = new TableInfo();
		ret.setFields(new HashMap<String,String>());
		ret.setTableName("User");
		ret.getFields().put("user_id", "integer");
		ret.getFields().put("long_field_name", "integer");
		ret.getFields().put("first_name", "string");
		ret.getFields().put("last_name", "string");
		ret.getFields().put("username", "string");
		ret.getFields().put("status", "integer");
		ret.setPkField("user_id");

		return ret;
	}

}


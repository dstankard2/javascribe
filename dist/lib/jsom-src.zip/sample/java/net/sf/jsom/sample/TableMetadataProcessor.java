package net.sf.jsom.sample;

import java.sql.Connection;

import net.sf.jsom.sample.configuration.EntityConfig;
import net.sf.jsom.sample.database.TableInfo;

public interface TableMetadataProcessor {

	public TableInfo readTableData(EntityConfig entity,Connection db);
	
}

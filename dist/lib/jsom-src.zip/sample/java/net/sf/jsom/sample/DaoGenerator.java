package net.sf.jsom.sample;

import java.util.List;

import net.sf.jsom.CodeGenerationException;
import net.sf.jsom.VariableTypeResolver;
import net.sf.jsom.java5.Java5ClassConstructor;
import net.sf.jsom.java5.Java5ClassDefinition;
import net.sf.jsom.java5.Java5CodeSnippet;
import net.sf.jsom.java5.Java5DeclaredMethod;
import net.sf.jsom.java5.Java5MethodParameter;
import net.sf.jsom.java5.Java5SourceFile;
import net.sf.jsom.sample.configuration.EntityConfig;
import net.sf.jsom.sample.configuration.ModelConfig;
import net.sf.jsom.sample.configuration.SearchIndexConfig;
import net.sf.jsom.sample.database.TableInfo;

public class DaoGenerator {

	public static Java5SourceFile createDao(TableInfo table,EntityConfig entity,ModelConfig model,DatabaseObjectNameResolver resolver,VariableTypeResolver types) throws CodeGenerationException {
		Java5SourceFile ret = null;
		Java5ClassDefinition def = null;
		String daoName = null;
		String beanName = null;
		List<SearchIndexConfig> indexes = null;
		SearchIndexConfig index = null;
		
		beanName = resolver.getJavaBeanName(entity.getTableName());
		daoName = beanName+"Dao";
		ret = new Java5SourceFile(types);
		ret.setPackageName(model.getDaoPackage());
		def = ret.getPublicClass();
		def.setClassName(daoName);
		ret.setSourceRootPath(model.getSourceRoot());

		addConstructor(entity,resolver,types,def,ret);
		
		indexes = entity.getSearchIndex();
		for(int i=0;i<indexes.size();i++) {
			index = indexes.get(i);
			if (index.getDelete().equals("true")) {
				addDeleteByIndex(index,entity,resolver,types,def,ret,table);
			}
			if (index.getSelect().equals("true")) {
				addSelectByIndex(index,entity,resolver,types,def,ret,table);
			}
		}
		
		return ret;
	}
	
	private static void addConstructor(EntityConfig entity,DatabaseObjectNameResolver resolver,VariableTypeResolver types,Java5ClassDefinition def,Java5SourceFile src) throws CodeGenerationException {
		Java5ClassConstructor con = null;
		Java5CodeSnippet code = null;
		
		code = new Java5CodeSnippet();
		con = new Java5ClassConstructor(types,def.getClassName());
		con.addArg("EntityManager", "mgr");
		code.append("entityManager = mgr;\n");
		con.setMethodBody(code);
		def.addMethod(con);
		def.addMemberVariable("entityManager", "EntityManager", null);
	}

	private static void addSelectByIndex(SearchIndexConfig index,EntityConfig entity,DatabaseObjectNameResolver resolver,VariableTypeResolver types,Java5ClassDefinition def,Java5SourceFile src,TableInfo info) throws CodeGenerationException {
		Java5DeclaredMethod method = null;
		Java5CodeSnippet code = null;
		String queryName = null;
		String entityName = null;
		
		entityName = resolver.getJavaBeanName(info.getTableName());
		queryName = "select"+GeneralUtils.getSearchIndexName(index, entity, resolver);
		code = new Java5CodeSnippet();
		method = new Java5DeclaredMethod(types);
		method.setMethodName(queryName);
		if (index.getMultiple().equals("true")) {
			method.setReturnType("list/"+entityName);
			code.addImport("java.util.ArrayList");
			code.append("ArrayList<"+entityName+"> returnValue = null;\n");
		} else {
			method.setReturnType(entityName);
			code.append(entityName+" returnValue = null;\n");
		}
		addIndexMethodParameters(method,index,info,resolver,types);
		code.merge(createQuery(queryName,index.getField(),resolver));
		if (index.getMultiple().equals("true")) {
			code.append("returnValue = q.getResultList();\n");
		} else {
			code.append("returnValue = q.getSingleResult();\n");
		}
		code.append("return returnValue;\n");
		method.setMethodBody(code);
		def.addMethod(method);
	}
	
	private static void addDeleteByIndex(SearchIndexConfig index,EntityConfig entity,DatabaseObjectNameResolver resolver,VariableTypeResolver types,Java5ClassDefinition def,Java5SourceFile src,TableInfo info) throws CodeGenerationException {
		Java5DeclaredMethod method = null;
		Java5CodeSnippet code = null;
		String queryName = null;
		
		queryName = "delete"+GeneralUtils.getSearchIndexName(index, entity, resolver);
		code = new Java5CodeSnippet();
		method = new Java5DeclaredMethod(types);
		method.setMethodName(queryName);
		addIndexMethodParameters(method,index,info,resolver,types);
		code.merge(createQuery(queryName,index.getField(),resolver));
		code.append("q.executeUpdate();\n");
		method.setMethodBody(code);
		def.addMethod(method);
	}
	
	private static void addIndexMethodParameters(Java5DeclaredMethod method,SearchIndexConfig ind,TableInfo info,DatabaseObjectNameResolver resolver,VariableTypeResolver types) throws CodeGenerationException {
		List<String> fields = null;
		String field = null;
		String type = null;
		String propertyName = null;
		Java5MethodParameter arg = null;
		
		fields = ind.getField();
		for(int i=0;i<fields.size();i++) {
			field = fields.get(i);
			type = info.getFields().get(field);
			propertyName = resolver.getJavaBeanPropertyName(field);
			arg = new Java5MethodParameter(types);
			arg.setName(propertyName);
			arg.setType(type);
			method.addArg(type, propertyName);
		}
	}
	
	private static Java5CodeSnippet createQuery(String queryName,List<String> fieldNames,DatabaseObjectNameResolver res) {
		Java5CodeSnippet ret = null;
		String fieldName = null;
		String propertyName = null;
		
		ret = new Java5CodeSnippet();
		ret.addImport("javax.persistence.Query");
		ret.append("Query q = entityManager.createNamedQuery(\""+queryName+"\");\n");
		for(int i=0;i<fieldNames.size();i++) {
			fieldName = fieldNames.get(i);
			propertyName = res.getJavaBeanPropertyName(fieldName);
			ret.append("q.setParameter(\""+propertyName+"\","+propertyName+");\n");
		}
		
		return ret;
	}
	
}

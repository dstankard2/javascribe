package net.sf.jsom.sample;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import net.sf.jsom.CodeGenerationException;
import net.sf.jsom.VariableTypeResolver;
import net.sf.jsom.java5.Java5Annotation;
import net.sf.jsom.java5.Java5ClassDefinition;
import net.sf.jsom.java5.Java5DataObjectSourceFile;
import net.sf.jsom.java5.Java5SourceFile;
import net.sf.jsom.java5.NVPAnnotationArgument;
import net.sf.jsom.sample.configuration.EntityConfig;
import net.sf.jsom.sample.configuration.ModelConfig;
import net.sf.jsom.sample.configuration.SearchIndexConfig;
import net.sf.jsom.sample.configuration.UpdateConfig;
import net.sf.jsom.sample.database.TableInfo;

public class EjbGenerator {

	public static Java5SourceFile createEjb(TableInfo table,EntityConfig entity,ModelConfig model,DatabaseObjectNameResolver resolver,VariableTypeResolver types) throws CodeGenerationException {
		Java5DataObjectSourceFile ret = null;
		Java5ClassDefinition def = null;
		String tableName = null;
		String beanName = null;
		HashMap<String,String> fields = null;
		Iterator<String> fieldNames = null;
		String fieldName = null;
		String type = null;
		String propertyName = null;
		Java5Annotation an = null;
		
		// For processing search indexes
		List<SearchIndexConfig> indexes = null;
		SearchIndexConfig index = null;
		Java5Annotation queries = null;
		StringBuilder whereClause = null;
		List<String> indexFields = null;
		String indexField = null;
		String indexName = null;
		
		// For processing updates on indexes
		List<UpdateConfig> updates = null;
		List<String> updateFields = null;
		UpdateConfig update = null;
		String updateField = null;
		String updateName = null;
		StringBuilder setClause = null;
		
		tableName = entity.getTableName();
		beanName = resolver.getJavaBeanName(tableName);
		ret = new Java5DataObjectSourceFile(types);
		ret.setPackageName(model.getEjbPackage());
		def = ret.getPublicClass();
		def.setClassName(beanName);
		ret.setSourceRootPath(model.getSourceRoot());
		fields = table.getFields();
		fieldNames = fields.keySet().iterator();
		while(fieldNames.hasNext()) {
			fieldName = fieldNames.next();
			propertyName = resolver.getJavaBeanPropertyName(fieldName);
			type = fields.get(fieldName);
			ret.addJavaBeanProperty(propertyName, type);
			an = new Java5Annotation("javax.persistence.Column");
			an.addArgument(new NVPAnnotationArgument("name","\""+fieldName+"\""));
			ret.addPropertyAnnotation(propertyName, an);
			if (table.getPkField().equals(fieldName)) {
				an = new Java5Annotation("javax.persistence.Id");
				ret.addPropertyAnnotation(propertyName, an);
			}
		}
		an = new Java5Annotation("javax.persistence.Entity");
		def.addAnnotation(an);
		an = new Java5Annotation("javax.persistence.Table","\""+tableName+"\"");
		def.addAnnotation(an);
		an = new Java5Annotation("javax.persistence.Inheritance");
		an.addArgument(new NVPAnnotationArgument("strategy","javax.persistence.InheritanceType.SINGLE_TABLE"));
		def.addAnnotation(an);
		an = new Java5Annotation("org.hibernate.annotations.Entity");
		an.addArgument(new NVPAnnotationArgument("dynamicInsert","true"));
		an.addArgument(new NVPAnnotationArgument("dynamicUpdate","true"));
		def.addAnnotation(an);
		an = new Java5Annotation("org.hibernate.annotations.BatchSize");
		an.addArgument(new NVPAnnotationArgument("size","30"));
		def.addAnnotation(an);
		
		// Add named queries
		queries = new Java5Annotation("javax.persistence.NamedQueries",true);
		def.addAnnotation(queries);

		indexes = entity.getSearchIndex();
		for(int i=0;i<indexes.size();i++) {
			index = indexes.get(i);
			indexName = GeneralUtils.getSearchIndexName(index, entity, resolver);
			indexFields = index.getField();
			whereClause = new StringBuilder();
			whereClause.append("where ");
			for(int i2=0;i2<indexFields.size();i2++) {
				if (i2>0) whereClause.append("and ");
				indexField = indexFields.get(i2);
				propertyName = resolver.getJavaBeanPropertyName(indexField);
				whereClause.append("tb."+propertyName+" = :"+propertyName+' ');
			}
			if (index.getDelete().equals("true")) {
				// Create a delete query
				queries.addNestedAnnotation(createQueryAnnotation("delete"+indexName,"delete from "+beanName+" tb "+whereClause.toString()));
			}
			updates = index.getUpdate();
			for(int i2=0;i2<updates.size();i2++) {
				update = updates.get(i2);
				updateName = update.getName();
				updateFields = update.getUpdateField();
				setClause = new StringBuilder();
				for(int i3=0;i3<updateFields.size();i3++) {
					updateField = updateFields.get(i3);
					propertyName = resolver.getJavaBeanPropertyName(updateField);
					if (i3>0) setClause.append(',');
					setClause.append("tb.").append(propertyName).append("=:")
					         .append(propertyName);
				}
				queries.addNestedAnnotation(createQueryAnnotation("update"+updateName+"On"+indexName,"update "+beanName+" tb set "+setClause+" "+whereClause.toString()));
			}
		}

		return ret;
	}
	
	private static Java5Annotation createQueryAnnotation(String name,String query) {
		Java5Annotation ret = null;
		
		ret = new Java5Annotation("javax.persistence.NamedQuery");
		ret.addArgument(new NVPAnnotationArgument("name","\""+name+"\""));
		ret.addArgument(new NVPAnnotationArgument("query","\""+query+"\""));

		return ret;
		
	}
	
}

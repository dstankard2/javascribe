package net.sf.jsom.sample.configuration;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="entity",propOrder={ "searchIndex"
})
public class EntityConfig {
	
	@XmlAttribute(required=true)
	private String tableName = null;
	
	@XmlElement(name="searchIndex")
	private List<SearchIndexConfig> searchIndex = new ArrayList<SearchIndexConfig>();

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public List<SearchIndexConfig> getSearchIndex() {
		return searchIndex;
	}

	public void setSearchIndex(List<SearchIndexConfig> searchIndex) {
		this.searchIndex = searchIndex;
	}

}


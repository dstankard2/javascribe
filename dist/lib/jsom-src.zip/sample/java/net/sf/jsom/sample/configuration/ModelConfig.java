package net.sf.jsom.sample.configuration;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
@XmlType(name="modelGenerator",propOrder={
		"entityConfig"
})
public class ModelConfig {

	@XmlAttribute(required=true)
	private String sourceRoot = null;
	
	@XmlAttribute(required=true)
	private String dbObjectNameResolver = null;
	
	@XmlAttribute(required=true)
	private String metadataProcessor = null;
	
	@XmlAttribute
	private String jdbcDriver = null;
	
	@XmlAttribute
	private String jdbcUrl = null;
	
	@XmlAttribute
	private String dbUser = null;
	
	@XmlAttribute
	private String dbPassword = null;
	
	@XmlAttribute
	private String ejbPackage = null;
	
	@XmlAttribute
	private String daoPackage = null;
	
	@XmlElement(name="entity")
	private List<EntityConfig> entityConfig = new ArrayList<EntityConfig>();

	public String getDbObjectNameResolver() {
		return dbObjectNameResolver;
	}

	public void setDbObjectNameResolver(String dbObjectNameResolver) {
		this.dbObjectNameResolver = dbObjectNameResolver;
	}

	public List<EntityConfig> getEntityConfig() {
		return entityConfig;
	}

	public void setEntityConfig(List<EntityConfig> entityConfig) {
		this.entityConfig = entityConfig;
	}

	public String getSourceRoot() {
		return sourceRoot;
	}

	public void setSourceRoot(String sourceRoot) {
		this.sourceRoot = sourceRoot;
	}

	public String getDbPassword() {
		return dbPassword;
	}

	public void setDbPassword(String dbPassword) {
		this.dbPassword = dbPassword;
	}

	public String getDbUser() {
		return dbUser;
	}

	public void setDbUser(String dbUser) {
		this.dbUser = dbUser;
	}

	public String getJdbcUrl() {
		return jdbcUrl;
	}

	public void setJdbcUrl(String jdbcUrl) {
		this.jdbcUrl = jdbcUrl;
	}

	public String getJdbcDriver() {
		return jdbcDriver;
	}

	public void setJdbcDriver(String jdbcDriver) {
		this.jdbcDriver = jdbcDriver;
	}

	public String getEjbPackage() {
		return ejbPackage;
	}

	public void setEjbPackage(String ejbPackage) {
		this.ejbPackage = ejbPackage;
	}

	public String getMetadataProcessor() {
		return metadataProcessor;
	}

	public void setMetadataProcessor(String metadataProcessor) {
		this.metadataProcessor = metadataProcessor;
	}

	public String getDaoPackage() {
		return daoPackage;
	}

	public void setDaoPackage(String daoPackage) {
		this.daoPackage = daoPackage;
	}
	
}

package net.sf.jsom.sample;

import net.sf.jsom.sample.configuration.EntityConfig;
import net.sf.jsom.sample.configuration.SearchIndexConfig;

public class GeneralUtils {

	public static String getSearchIndexName(SearchIndexConfig ind,EntityConfig en,DatabaseObjectNameResolver res) {
		StringBuilder build = new StringBuilder();
		
		build.append(res.getJavaBeanName(en.getTableName()));
		build.append("By").append(ind.getName());
		
		return build.toString();
	}
}

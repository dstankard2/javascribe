package net.sf.jsom.sample.configuration;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="update",propOrder={ "updateField" })
public class UpdateConfig {

	@XmlAttribute
	private String name = null;

	@XmlElement(name="updateField")
	private List<String> updateField = new ArrayList<String>();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<String> getUpdateField() {
		return updateField;
	}

	public void setUpdateField(List<String> updateField) {
		this.updateField = updateField;
	}
	
}

package net.sf.jsom.java5;

import net.sf.jsom.CodeGenerationException;
import net.sf.jsom.CodeSnippet;

public class Java5TypeImpl implements Java5Type {
	protected String className = null;
	protected String im = null;
	protected String name = null;
	
	public Java5TypeImpl() {
	}
	
	public Java5TypeImpl(String name,String im,String className) {
		this.name = name;
		this.im = im;
		this.className = className;
	}
	
	public CodeSnippet instantiate(String varName,String value) throws CodeGenerationException {
		Java5CodeSnippet ret = new Java5CodeSnippet();
		
		ret.append(varName+" = new "+className+"();\n");
		return ret;
	}
	public CodeSnippet declare(String varName) throws CodeGenerationException {
		Java5CodeSnippet ret = new Java5CodeSnippet();
		
		ret.addImport(im);
		ret.append(className+" "+varName+";\n");
		
		return ret;
	}

	public String getImport() {
		return im;
	}
	
	public void setImport(String s) {
		im = s;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}

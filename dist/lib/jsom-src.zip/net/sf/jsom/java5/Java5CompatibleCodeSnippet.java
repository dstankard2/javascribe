package net.sf.jsom.java5;

import java.util.List;
import net.sf.jsom.CodeSnippet;

/**
 * This code snippet represents code that can be compiled in Java 5.  
 * @author Dave
 *
 */
public interface Java5CompatibleCodeSnippet extends CodeSnippet {
	
	public void addImport(String s);
	public List<String> getRequiredImports();
	
}

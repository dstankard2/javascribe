package net.sf.jsom.java5;

import java.util.List;

/**
 * Represents an argument to a Java 5 annotation.
 * @author Dave
 */
public interface AnnotationArgument {
	
	public String getCode();
	public List<String> getImports();
	
}
